#include "topicos_avancados_components/globals.h"
#include "topicos_avancados_components/display.h"
#include "topicos_avancados_components/keyboard.h"
#include "topicos_avancados_components/mouse.h"
#include "topicos_avancados_components/timer.h"
#include "topicos_avancados_components/init.h"
#include "topicos_avancados_components/lighting.h"


/**************************************
************ FUNÇÃO MAIN **************
**************************************/

int main(int argc, char **argv)
{
  estado.doubleBuffer = GL_TRUE;

  glutInit(&argc, argv);
  glutInitWindowPosition(0, 0);
  glutInitWindowSize(400,400);
  glutInitDisplayMode(((estado.doubleBuffer) ? GLUT_DOUBLE : GLUT_SINGLE) | GLUT_RGB | GLUT_DEPTH);
  if (glutCreateWindow("Cubo") == GL_FALSE)
    exit(1);

  init();

  imprime_ajuda();

  /* Registar callbacks do GLUT */

  // Callbacks de janelas/desenho
  glutReshapeFunc(reshape);
  glutDisplayFunc(draw);

  // Callbacks de teclado
  glutKeyboardFunc(key);
  //glutKeyboardUpFunc(keyUp);
  glutSpecialFunc(specialKey);
  //glutSpecialUpFunc(SpecialKeyUp);

  // Callbacks do rato
  //glutPassiveMotionFunc(MousePassiveMotion);
  //glutMotionFunc(MouseMotion);
  glutMouseFunc(mouse);

  // Callbacks timer/idle
  glutTimerFunc(estado.delayMovimento, timer, 0);
  //glutIdleFunc(Idle);

  lighting();

  // Começar
  glutMainLoop();

  return 0;
}
