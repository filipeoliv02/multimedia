#include "timer.h"
#include "globals.h"

/**************************************
******** CALLBACKS TIME/IDLE **********
**************************************/

/* Callback Idle */
void idle(void)
{
  /* Ações a tomar quando o GLUT está idle */

  /* Redesenhar o ecrã */
  // glutPostRedisplay();
}

/* Callback de temporizador */
void timer(int value)
{
  glutTimerFunc(estado.delayMovimento, timer, 0);
  /* ... accoes do temporizador não colocar aqui transformações, alterar
     somente os valores das variáveis ... */

  // alterar o modelo.theta[] usando a variável modelo.eixoRodar como indice

if(estado.movimentoRotacao)
  {
    modelo.theta[modelo.eixoRodar]+=modelo.deltaRotacao;
  
    if(modelo.theta[modelo.eixoRodar]>360)
      modelo.theta[modelo.eixoRodar]-=360;
  }
  
  /* redesenhar o ecrã */
  glutPostRedisplay();
}