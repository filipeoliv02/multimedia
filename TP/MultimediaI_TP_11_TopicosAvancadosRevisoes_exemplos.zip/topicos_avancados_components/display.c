#include "display.h"
#include "globals.h"
#include "cubo.h"

/**************************************
***** CALL BACKS DE JANELA/DESENHO ****
**************************************/

/* Callback para redimensionar janela */
void reshape(int width, int height)
{
  glViewport(0, 0, (GLint) width, (GLint) height);  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  if (width < height)
     glOrtho(-5, 5, -5*(GLdouble)height/width, 5*(GLdouble)height/width,-10,10);
  else
     glOrtho(-5*(GLdouble)width/height, 5*(GLdouble)width/height,-5, 5, -10,10);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

}

/* Callback de desenho */
void draw(void)
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // ... chamada das rotinas auxiliares de desenho ...

  glPushMatrix();
    glRotatef(modelo.theta[0],1,0,0);
    glRotatef(modelo.theta[1],0,1,0);
    glRotatef(modelo.theta[2],0,0,1);
    
    glPushMatrix();
      glScalef(modelo.ladoCubo,modelo.ladoCubo,modelo.ladoCubo);
      cubo();
    glPopMatrix();
    
  glPopMatrix();

  if (estado.doubleBuffer)
    glutSwapBuffers();
  else
    glFlush();
}
