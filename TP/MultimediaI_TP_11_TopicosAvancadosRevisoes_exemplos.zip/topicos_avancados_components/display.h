void reshape(int width, int height);
void draw(void);