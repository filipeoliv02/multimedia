#include "keyboard.h"
#include "globals.h"
#include "init.h"

/**************************************
********* CALLBACKS TECLADO ***********
**************************************/

/* Callback para interação via teclado (carregar na tecla) */
void key(unsigned char key, int x, int y)
{
  if(DEBUG)
    printf("Carregou na tecla %c\n",key);

  switch (key) {
    case 27:
      exit(1);
    /* ... accoes sobre outras teclas ... */

    case 'h' :
    case 'H' :
                imprime_ajuda();
            break;
    case '+':
            if(modelo.ladoCubo<LADO_MAXIMO)
            {
              modelo.ladoCubo+=DELTA_LADO;
              glutPostRedisplay();
            }
          break;

    case '-':
            if(modelo.ladoCubo>LADO_MINIMO)
            {
              modelo.ladoCubo-=DELTA_LADO;
              glutPostRedisplay();
            }
          break;

    case 'i' :
    case 'I' :
            inicia_modelo();
            glutPostRedisplay();
          break;

    case 'c' :
    case 'C' :
            if(glIsEnabled(GL_CULL_FACE)){
              glDisable(GL_CULL_FACE);
              printf("Culling desativado\n");
            } else {
              glEnable(GL_CULL_FACE);
              printf("Culling ativado\n");
            } 
          break;

    case 'n' :
    case 'N' :
            if(glIsEnabled(GL_NORMALIZE)){
              glDisable(GL_NORMALIZE);
              printf("Normais desativadas\n");
            } else {
              glEnable(GL_NORMALIZE);
              printf("Normais ativadas\n");
            }           
          break;

    case 't' :
    case 'T' :
            if(glIsEnabled(GL_BLEND)){
              glDisable(GL_BLEND);
              printf("Transparências desativadas\n");
            } else {
              glEnable(GL_BLEND);
              printf("Transparências ativadas\n");
            }
          break;

    case 'l' :
    case 'L' :
            if(glIsEnabled(GL_LIGHTING)){
              glDisable(GL_LIGHTING);
              printf("Luzes desligadas\n");
            } else {
              glEnable(GL_LIGHTING);
              printf("Luzes ligadas\n");
            }
          break;

  }
}

/* Callback para interação via teclado (largar a tecla) */
void keyUp(unsigned char key, int x, int y)
{
  if(DEBUG)
    printf("Largou a tecla %c\n",key);
}

/* Callback para interacção via teclas especiais (carregar na tecla) */
void specialKey(int key, int x, int y)
{
  /* Ações sobre outras teclas especiais
      GLUT_KEY_F1 ... GLUT_KEY_F12
      GLUT_KEY_UP
      GLUT_KEY_DOWN
      GLUT_KEY_LEFT
      GLUT_KEY_RIGHT
      GLUT_KEY_PAGE_UP
      GLUT_KEY_PAGE_DOWN
      GLUT_KEY_HOME
      GLUT_KEY_END
      GLUT_KEY_INSERT */

  switch (key)
  {
    /* Redesenhar o ecrã */
    //glutPostRedisplay();
    case GLUT_KEY_F1:
      inicia_modelo();
      glutPostRedisplay();
      break;
    case GLUT_KEY_F2:
      glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
      glutPostRedisplay();
      break;
    case GLUT_KEY_F3:
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
      glutPostRedisplay();
      break;
    case GLUT_KEY_F4:
      glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
      glutPostRedisplay();
      break;
  }

  if (DEBUG)
    printf("Carregou na tecla especial %d\n", key);
}

/* Callback para interação via teclas especiais (largar a tecla) */
void specialKeyUp(int key, int x, int y)
{

  if (DEBUG)
    printf("Largou a tecla especial %d\n", key);
}


/**************************************
*********** FUNÇÃO AJUDA **************
**************************************/

void imprime_ajuda(void)
{
  printf("\n\nDesenho de um quadrado\n");
  printf("h,H - Ajuda \n");
  printf("F1  - Reiniciar \n");
  printf("F2  - Poligono Fill \n");
  printf("F3  - Poligono Line \n");
  printf("F4  - Poligono Point \n");
  printf("+   - Aumentar tamanho do cubo\n");
  printf("-   - Diminuir tamanho do cubo\n");
  printf("i,I - Reiniciar Variáveis\n");
  printf("c,C - Toggle Culling\n");
  printf("n,N - Toggle Normais\n");
  printf("t,T - Toggle Transparências\n");
  printf("l,L - Toggle Luzes\n");
  printf("ESC - Sair\n");
  printf("teclas do rato para iniciar/parar rotação e alternar eixos\n");

}
