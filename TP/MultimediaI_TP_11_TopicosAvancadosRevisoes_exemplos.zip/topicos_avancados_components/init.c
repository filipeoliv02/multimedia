#include "init.h"
#include "globals.h"

/**************************************
*** INICIALIZAÇÃO DO AMBIENTE OPENGL **
**************************************/

void inicia_modelo()
{
  estado.delayMovimento=50;
  estado.movimentoRotacao=GL_FALSE;

  modelo.theta[0]=45;
  modelo.theta[1]=45;
  modelo.theta[2]=45;
  modelo.eixoRodar=0;  // eixo de X;
  modelo.ladoCubo=3;

  modelo.deltaRotacao=5;
}

void init(void)
{
  inicia_modelo();
  glClearColor(0.0, 0.0, 0.0, 0.0);
  glEnable(GL_POINT_SMOOTH);
  glEnable(GL_LINE_SMOOTH);
  glEnable(GL_POLYGON_SMOOTH);
  glEnable(GL_DEPTH_TEST);
}

