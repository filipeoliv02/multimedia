void idle(void);
void timer(int value);