void inicia_modelo();
void init(void);