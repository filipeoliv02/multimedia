void mouseMotion(int x, int y);
void mousePassiveMotion(int x, int y);
void mouse(int button, int state, int x, int y);
