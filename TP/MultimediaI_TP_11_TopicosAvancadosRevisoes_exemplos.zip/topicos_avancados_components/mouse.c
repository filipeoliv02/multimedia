#include "mouse.h"
#include "globals.h"

/**************************************
*********** CALLBACKS RATO ************
**************************************/

void mouseMotion(int x, int y)
{
    /* x,y    => coordenadas do ponteiro quando se move no rato
                 a carregar em teclas
    */

  if(DEBUG)
    printf("Mouse Motion %d %d\n",x,y);

}

void mousePassiveMotion(int x, int y)
{
    /* x,y    => coordenadas do ponteiro quando se move no rato
                 sem estar a carregar em teclas
    */

  if(DEBUG)
    printf("Mouse Passive Motion %d %d\n",x,y);

}

void mouse(int button, int state, int x, int y)
{
  /* button => GLUT_LEFT_BUTTON, GLUT_MIDDLE_BUTTON, GLUT_RIGHT_BUTTON
     state  => GLUT_UP, GLUT_DOWN
     x,y    => coordenadas do ponteiro quando se carrega numa tecla do rato
  */

  // alterar o eixo que roda (variável modelo.eixoRodar)

  switch(button){
    case GLUT_LEFT_BUTTON :      
      if(state == GLUT_DOWN)
      {        
        if(modelo.eixoRodar==0 || !estado.movimentoRotacao)
          estado.movimentoRotacao=!estado.movimentoRotacao;
        modelo.eixoRodar=0;
      }
     break;
    case GLUT_MIDDLE_BUTTON :      
      if(state == GLUT_DOWN)
      {      
        if(modelo.eixoRodar==1 || !estado.movimentoRotacao)
          estado.movimentoRotacao=!estado.movimentoRotacao;
        modelo.eixoRodar=1;  
      }
      break;
    case GLUT_RIGHT_BUTTON :
      if(state == GLUT_DOWN)
      {        
        if(modelo.eixoRodar==2 || !estado.movimentoRotacao)
          estado.movimentoRotacao=!estado.movimentoRotacao;
        modelo.eixoRodar=2;
      }
      break;
  }
  if(DEBUG)
    printf("Mouse button:%d state:%d coord:%d %d\n",button,state,x,y);
}