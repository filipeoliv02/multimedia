#include "globals.h"
#include "cubo.h"

/**************************************
** ESPAÇO PARA DEFINIÇÃO DAS ROTINAS **
****** AUXILIARES DE DESENHO ... ******
**************************************/

void desenhaPoligono(GLfloat a[], GLfloat b[], GLfloat c[], GLfloat  d[], GLfloat cor[], GLfloat normal[])
{
  glBegin(GL_POLYGON);
    glNormal3fv(normal);
    glColor4fv(cor);
    glVertex3fv(a);
    glVertex3fv(b);
    glVertex3fv(c);
    glVertex3fv(d);
  glEnd();
}

void cubo()
{
 GLfloat vertices[][3] = {  {-0.5,-0.5,-0.5}, 
                            {0.5,-0.5,-0.5}, 
                            {0.5,0.5,-0.5}, 
                            {-0.5,0.5,-0.5}, 
                            {-0.5,-0.5,0.5},  
                            {0.5,-0.5,0.5}, 
                            {0.5,0.5,0.5}, 
                            {-0.5,0.5,0.5}};

  GLfloat cores[][4] = {{0.0,1.0,1.0,0.5},
                        {1.0,0.0,0.0,0.5},
                        {1.0,1.0,0.0,0.5}, 
                        {0.0,1.0,0.0,0.5}, 
                        {1.0,0.0,1.0,0.5}, 
                        {0.0,0.0,1.0,0.5}, 
                        {1.0,1.0,1.0,0.5}};

  GLfloat normais[][3] = {  {0,0,-1}, 
                            {0,1,0}, 
                            {-1,0,0}, 
                            {1,0,0}, 
                            {0,0,1},  
                            {0,-1,0}};

  //desenhaPoligono(vertices[1],vertices[0],vertices[3],vertices[2],cores[0],normais[0]);
  desenhaPoligono(vertices[2],vertices[3],vertices[0],vertices[1],cores[0],normais[0]);
  //desenhaPoligono(vertices[2],vertices[3],vertices[0],vertices[1],cores[0],normais[4]);
  desenhaPoligono(vertices[2],vertices[3],vertices[7],vertices[6],cores[1],normais[1]);
  desenhaPoligono(vertices[3],vertices[0],vertices[4],vertices[7],cores[2],normais[2]);
  desenhaPoligono(vertices[6],vertices[5],vertices[1],vertices[2],cores[3],normais[3]);
  desenhaPoligono(vertices[4],vertices[5],vertices[6],vertices[7],cores[4],normais[4]);
  desenhaPoligono(vertices[5],vertices[4],vertices[0],vertices[1],cores[5],normais[5]);

}

