#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#if defined(__APPLE__) || defined(MACOSX)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

/**************************************
************* CONSTANTE PI ************
**************************************/

#ifndef M_PI
#define M_PI 3.1415926535897932384626433832795
#endif

/**************************************
* AUXILIARES CONVERSÃO GRAUS-RADIANOS *
**************************************/

#define rtd(x) (180 * (x) / M_PI)
#define dtr(x) (M_PI * (x) / 180)

/**************************************
********** MACROS AUXILIARES **********
**************************************/

#define DEBUG 1

#define MENU_EXIT			1
#define MENU_WIREFRAME		20
#define MENU_SOLID			21
#define MENU_SHOW_AXIS		22	
#define MENU_HIDE_AXIS		23
#define MENU_RESET_CAMERA			38
#define MENU_RESET_CAMERAORG		39

#define POLAR_VIEW

#define BASE_RADIUS			0.5
#define BASE_HEIGHT			0.25
#define SEG1_WIDTH			0.25
#define SEG1_LENGTH			1.5
#define SEG2_WIDTH			0.25
#define SEG2_LENGTH			1.5
#define WRIST_WIDTH			0.125
#define WRIST_LENGTH		0.25
#define CLAW_BASE_WIDTH		0.25
#define CLAW_BASE_LENGTH	0.01
#define CLAW_WIDTH			0.05
#define CLAW_LENGTH			0.1

/**************************************
********** VARIÁVEIS GLOBAIS **********
**************************************/

typedef struct 
{
  GLfloat distance;
	GLfloat twist;
	GLfloat elevation;
	GLfloat azimuth;
} PolarCamara;

typedef struct
{
  GLfloat x;
	GLfloat y;
	GLfloat z;

	GLfloat cx;
	GLfloat cy;
	GLfloat cz;

	GLfloat ux;
	GLfloat uy;
	GLfloat uz;
} EyeCamara;

typedef struct 
{
  GLfloat rotBase;
	GLfloat rotSeg1;
	GLfloat rotSeg2;
	GLfloat rotWrist;
	GLfloat rotClaw;
	GLboolean clawOpened;
} RobotArm;

typedef struct 
{
	PolarCamara polarCam;
  EyeCamara eyeCam;
	GLenum mode;
	GLboolean showAxis;
} Estado;

typedef struct 
{
	RobotArm braco;
} Modelo;

Estado estado;
Modelo modelo;

/**************************************
*** INICIALIZAÇÃO DO AMBIENTE OPENGL **
**************************************/

#ifdef POLAR_VIEW
void reset_camera()
{
	estado.polarCam.distance = 8;
  estado.polarCam.twist = 0;
  estado.polarCam.elevation = 45;
  estado.polarCam.azimuth = 360-33;
}

void reset_camera_org()
{
	estado.polarCam.distance = 8;
  estado.polarCam.twist = 0;
  estado.polarCam.elevation = 0;
  estado.polarCam.azimuth = 0;
}
#else
void reset_camera()
{
	estado.eyeCam.x = -0.6;
  estado.eyeCam.y = -0.9;
  estado.eyeCam.z = -6;
}

void reset_camera_org()
{
	estado.eyeCam.x = 0;
  estado.eyeCam.y = 0;
  estado.eyeCam.z = 6;
}
#endif

void setview()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	//glOrtho(-3.0, 3.0, -3.0, 3.0, 0.1, 20.0);
	gluPerspective(60, 1, 1, 10);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

  #ifdef POLAR_VIEW
  	glTranslated(0.0, 0.0, -estado.polarCam.distance);
	  glRotated(estado.polarCam.elevation, 1.0, 0.0, 0.0);
	  glRotated(estado.polarCam.azimuth, 0.0, 1.0, 0.0);
	  glRotated(estado.polarCam.twist, 0.0, 0.0, 1.0);
  #else
    gluLookAt(estado.eyeCam.x, estado.eyeCam.y, estado.eyeCam.z, 
              estado.eyeCam.cx, estado.eyeCam.cy, estado.eyeCam.cz, 
              estado.eyeCam.ux, estado.eyeCam.uy, estado.eyeCam.uz);
  #endif
}

void init_estado()
{
	estado.mode = GLU_LINE;
  #ifdef POLAR_VIEW
    estado.polarCam.distance = 6;
    estado.polarCam.twist = 0;
    estado.polarCam.elevation = 0;
    estado.polarCam.azimuth = 2;
  #else
    estado.eyeCam.x = 0;
    estado.eyeCam.y = 0;
    estado.eyeCam.z = 6;
    estado.eyeCam.cx = 0;
    estado.eyeCam.cy = 0;
    estado.eyeCam.cz = 0;
    estado.eyeCam.ux = 0;
    estado.eyeCam.uy = 1;
    estado.eyeCam.uz = 0;
  #endif
	estado.showAxis = GL_TRUE;
}

void init_modelo()
{
	modelo.braco.rotBase = 0.0;
  modelo.braco.rotSeg1 = 0.0;
  modelo.braco.rotSeg2 = 0.0;
  modelo.braco.rotWrist = 0.0;
  modelo.braco.rotClaw = 0.0;
  modelo.braco.clawOpened = GL_TRUE;
}

void init(void)
{
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_DEPTH_TEST);

	setview();
	reset_camera();
}

/**************************************
***** CALL BACKS DE JANELA/DESENHO ****
**************************************/

/* Callback para redimensionar janela */
void reshape(int width, int height)
{
  GLint size;

  if (width < height)
    size = width;
  else
    size = height;

  /* glViewport(botom, left, width, height)
     Define parte da janela a ser utilizada pelo OpenGL */
  glViewport(0, 0, (GLint)size, (GLint)size);

  setview();  
}

void drawAxis(GLfloat size)
{
	GLfloat mat_r[] = {1.0, 0.0, 0.0, 1.0};
	GLfloat mat_g[] = {0.0, 1.0, 0.0, 1.0};
	GLfloat mat_b[] = {0.0, 0.0, 1.0, 1.0};

	glPushAttrib(GL_LINE_BIT);
	//glLineWidth(2.0);
	glBegin(GL_LINES);
		// XX
		glColor4fv(mat_r);
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_r);
		glNormal3f(0.0, 0.0, 1.0);
		glVertex3f(-size, 0, 0);
		glVertex3f(+size, 0, 0);

		// YY
		glColor4fv(mat_g);
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_g);
		glNormal3f(0.0, 0.0, 1.0);
		glVertex3f(0, -size, 0);
		glVertex3f(0, +size, 0);

		// ZZ
		glColor4fv(mat_b);
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_b);
		glNormal3f(0.0, 0.0, 1.0);
		glVertex3f(0, 0, -size);
		glVertex3f(0, 0, +size);
	glEnd();
	glPopAttrib();
}


/**************************************
** ESPAÇO PARA DEFINIÇÃO DAS ROTINAS **
****** AUXILIARES DE DESENHO ... ******
**************************************/

void cylinderWithTopAndBottom(GLenum mode, GLfloat radius, GLfloat height, GLuint slices, GLuint stacks)
{
	GLUquadricObj* qobj = gluNewQuadric();
	gluQuadricDrawStyle(qobj, mode); //GLU_LINE //GLU_FILL
	gluQuadricNormals(qobj, GLU_SMOOTH);

	glPushMatrix();
		gluDisk(qobj, 0, radius, slices, stacks);
		gluCylinder(qobj, radius, radius, height, slices, stacks);
		glTranslatef(0, 0, height);
		gluDisk(qobj, 0, radius, slices, stacks);
	glPopMatrix();
	
	gluDeleteQuadric(qobj);
}

void box(GLenum mode, GLfloat width, GLfloat height)
{
	GLfloat radius = sqrt(2*width*width)/2;
	cylinderWithTopAndBottom(mode, radius, height, 4, 2);
}

void robotArmDisplay(GLenum mode, GLboolean showAxis)
{
	GLfloat mat_1[] = {0.6, 0.6, 0.6, 1.0};
	GLfloat mat_2[] = {1, 1, 0, 1.0};
	GLfloat mat_3[] = {0, 1, 1, 1.0};
	GLfloat mat_4[] = {1, 1, 1, 1.0};
	GLfloat mat_5[] = {1, 0, 1, 1.0};

	glPushMatrix();
		//base
		glRotatef(modelo.braco.rotBase, 0, 0, 1);
		if (showAxis)
			drawAxis(0.5);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_1);
		cylinderWithTopAndBottom(mode, BASE_RADIUS, BASE_HEIGHT, 12, 2);

		//segmento 1
		glTranslatef(0, 0, BASE_HEIGHT);
		glRotatef(modelo.braco.rotSeg1, 1, 0, 0);
		if (showAxis)
			drawAxis(0.5);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_2);
		box(mode, SEG1_WIDTH, SEG1_LENGTH);

		//segmento 2
		glTranslatef(0, 0, SEG1_LENGTH);
		glRotatef(modelo.braco.rotSeg2, 1, 0, 0);
		if (showAxis)
			drawAxis(0.5);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_2);
		box(mode, SEG2_WIDTH, SEG2_LENGTH);

		//pulso
		glTranslatef(0, 0, SEG2_LENGTH);
		glRotatef(modelo.braco.rotWrist, 1, 0, 0);
		if (showAxis)
			drawAxis(0.5);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_3);
		box(mode, WRIST_WIDTH, WRIST_LENGTH);

		//garra
		glTranslatef(0, 0, WRIST_LENGTH);
		glRotatef(modelo.braco.rotClaw, 0, 0, 1);
		if (showAxis)
			drawAxis(0.5);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_4);
		box(mode, CLAW_BASE_WIDTH, CLAW_BASE_LENGTH);

		// pinças
		glTranslatef(0, 0, CLAW_BASE_LENGTH);
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_5);
		float d;
		if (modelo.braco.clawOpened)
			d = CLAW_BASE_WIDTH/2;
		else
			d = CLAW_WIDTH/2;

		// pinça "direita"
		glPushMatrix();
			glTranslatef(-d, 0, 0);
			box(mode, CLAW_WIDTH, CLAW_LENGTH);
		glPopMatrix();

		// pinça "esquerda"
		glPushMatrix();
			glTranslatef(+d, 0, 0);
			box(mode, CLAW_WIDTH, CLAW_LENGTH);
		glPopMatrix();
	glPopMatrix();
}

/* Callback de desenho */
void display(void)
{
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// posicionar camara
	#ifdef POLAR_VIEW
  	glTranslated(0.0, 0.0, -estado.polarCam.distance);
	  glRotated(estado.polarCam.elevation, 1.0, 0.0, 0.0);
	  glRotated(estado.polarCam.azimuth, 0.0, 1.0, 0.0);
	  glRotated(estado.polarCam.twist, 0.0, 0.0, 1.0);
  #else
    gluLookAt(estado.eyeCam.x, estado.eyeCam.y, estado.eyeCam.z, 
              estado.eyeCam.cx, estado.eyeCam.cy, estado.eyeCam.cz, 
              estado.eyeCam.ux, estado.eyeCam.uy, estado.eyeCam.uz);
  #endif

	// sistema global de coordenadas
	drawAxis(3);

	// colocar desenho alinhado com eixo Y
	glRotatef(-90, 1, 0, 0);

	// desenhar a cena
	robotArmDisplay(estado.mode, estado.showAxis);

	glutSwapBuffers();
}

/**************************************
******** CALLBACKS TIME/IDLE **********
**************************************/

/* Callback Idle */
void idle(void)
{
  /* Ações a tomar quando o GLUT está idle */

  /* Redesenhar o ecrã */
  // glutPostRedisplay();
}

/* Callback de temporizador */
void timer(int value)
{
  //glutTimerFunc(estado.delay, timer, 0);
  
  /* Acções do temporizador ...
     Não colocar aqui primitivas OpenGL de desenho glBegin, glEnd, etc.
     Simplesmente alterar os valores de modelo.hora.hor, modelo.hora.min e modelo.hora.seg */


  /* Redesenhar o ecrã (invoca o callback de desenho) */
  glutPostRedisplay();
}

/**************************************
*********** FUNÇÃO AJUDA **************
**************************************/

void imprime_ajuda(void)
{
  printf("\n\nBraço do Robot:\n");
  printf("?     - Ajuda \n");
  printf("q,Q   - Incrementar Rotação Base\n");
  printf("a,A   - Decrementar Rotação Base\n");
  printf("w,W   - Incrementar Rotação Segmento 1\n");
  printf("s,S   - Decrementar Rotação Segmento 1\n");
  printf("e,E   - Incrementar Rotação Segmento 2\n");
  printf("d,D   - Decrementar Rotação Segmento 2\n");
  printf("r,R   - Incrementar Rotação Pulso\n");
  printf("f,F   - Decrementar Rotação Pulso\n");
  printf("t,T   - Incrementar Rotação Garra\n");
  printf("g,G   - Decrementar Rotação Garra\n");
  printf("Space - Mexer Garra\n");
  printf("\nCamera:\n");
  printf("c,C   - Reset Camera\n");
  printf("o,O   - Reset Camera Origem\n");
#ifdef POLAR_VIEW
  printf("x     - Diminuir Azimuth\n");
  printf("X     - Aumentar Azimuth\n");
  printf("y     - Diminuir Elevação\n");
  printf("Y     - Aumentar Elevação\n");
  printf("z     - Diminuir Distância\n");
  printf("Z     - Aumentar Distância\n");
  printf("u     - Diminuir Twist\n");
  printf("U     - Aumentar Twist\n");
#else
  printf("x     - Diminuir X\n");
  printf("X     - Aumentar X\n");
  printf("y     - Diminuir Y\n");
  printf("Y     - Aumentar Y\n");
  printf("z     - Diminuir Z\n");
  printf("Z     - Aumentar Z\n");
#endif
  printf("\nESC - Sair\n");
}

/**************************************
********* CALLBACKS TECLADO ***********
**************************************/

/* Callback para interação via teclado (carregar na tecla) */
void key(unsigned char key, int x, int y)
{
  switch (key)
	{
    case 27:
      exit(0);
      break;
    case '?':
      imprime_ajuda();
      break;
    case 'q':
    case 'Q':
      modelo.braco.rotBase += 3;
      if (modelo.braco.rotBase > 360.0)
        modelo.braco.rotBase = 0;
      break;
    case 'a':
    case 'A':
      modelo.braco.rotBase -= 3;
      if (modelo.braco.rotBase < 0)
        modelo.braco.rotBase = 360;
      break;
    case 'w':
    case 'W':
      modelo.braco.rotSeg1 += 3;
      if (modelo.braco.rotSeg1 > 360.0)
        modelo.braco.rotSeg1 = 0;
      break;
    case 'S':
    case 's':
      modelo.braco.rotSeg1 -= 3;
      if (modelo.braco.rotSeg1 < 0)
        modelo.braco.rotSeg1 = 360;
      break;
    case 'e':
    case 'E':
      modelo.braco.rotSeg2 += 3;
      if (modelo.braco.rotSeg2 > 360.0)
        modelo.braco.rotSeg2 = 0;
      break;
    case 'd':
    case 'D':
      modelo.braco.rotSeg2 -= 3;
      if (modelo.braco.rotSeg2 < 0)
        modelo.braco.rotSeg2 = 360;
      break;
    case 'r':
    case 'R':
      modelo.braco.rotWrist += 3;
      if (modelo.braco.rotWrist > 360.0)
        modelo.braco.rotWrist = 0;
      break;
    case 'f':
    case 'F':
      modelo.braco.rotWrist -= 3;
      if (modelo.braco.rotWrist < 0)
        modelo.braco.rotWrist = 360;
      break;
    case 't':
    case 'T':
      modelo.braco.rotClaw += 3;
      if (modelo.braco.rotClaw > 360.0)
        modelo.braco.rotClaw = 0;
      break;
    case 'g':
    case 'G':
      modelo.braco.rotClaw -= 3;
      if (modelo.braco.rotClaw < 0)
        modelo.braco.rotClaw = 360;
      break;
    case ' ':
      modelo.braco.clawOpened = !modelo.braco.clawOpened;
      break;
#ifdef POLAR_VIEW
    case 'x':
      estado.polarCam.azimuth -= 2;
      if (estado.polarCam.azimuth < 0)
        estado.polarCam.azimuth = 360;
      break;
    case 'X':
      estado.polarCam.azimuth += 2;
      if (estado.polarCam.azimuth > 360)
        estado.polarCam.azimuth = 0;
      break;
    case 'y':
      estado.polarCam.elevation -= 2;
      if (estado.polarCam.elevation < 0)
        estado.polarCam.elevation = 360;
      break;
    case 'Y':
      estado.polarCam.elevation += 2;
      if (estado.polarCam.elevation > 360)
        estado.polarCam.elevation = 0;
      break;
    case 'z':
      estado.polarCam.distance -= 2;
      break;
    case 'Z':
      estado.polarCam.distance += 2;
      break;
    case 'u':
      estado.polarCam.twist -= 2;
      if (estado.polarCam.twist < 0)
        estado.polarCam.twist = 360;
      break;
    case 'U':
      estado.polarCam.twist += 2;
      if (estado.polarCam.twist > 360)
        estado.polarCam.twist = 0;
      break;
#else
    case 'x':
      estado.eyeCam.x -= 0.1;
      break;
    case 'X':
      estado.eyeCam.x += 0.1;
      break;
    case 'y':
      estado.eyeCam.y -= 0.1;
      break;
    case 'Y':
      estado.eyeCam.y += 0.1;
      break;
    case 'z':
      estado.eyeCam.z -= 0.1;
      break;
    case 'Z':
      estado.eyeCam.z += 0.1;
      break;
#endif
    case 'c':
    case 'C':
      reset_camera();
      break;	
    case 'o':
    case 'O':
      reset_camera_org();
      break;	
	}
	glutPostRedisplay();

  if (DEBUG)
    printf("Carregou na tecla %c\n", key);
}

/* Callback para interação via teclado (largar a tecla) */
void keyUp(unsigned char key, int x, int y)
{
  if (DEBUG)
    printf("Largou a tecla %c\n", key);
}

/* Callback para interacção via teclas especiais (carregar na tecla) */
void specialKey(int key, int x, int y)
{
  /* Ações sobre outras teclas especiais
      GLUT_KEY_F1 ... GLUT_KEY_F12
      GLUT_KEY_UP
      GLUT_KEY_DOWN
      GLUT_KEY_LEFT
      GLUT_KEY_RIGHT
      GLUT_KEY_PAGE_UP
      GLUT_KEY_PAGE_DOWN
      GLUT_KEY_HOME
      GLUT_KEY_END
      GLUT_KEY_INSERT */

  switch (key)
  {
    /* Redesenhar o ecrã */
    //glutPostRedisplay();
  }

  if (DEBUG)
    printf("Carregou na tecla especial %d\n", key);
}

/* Callback para interação via teclas especiais (largar a tecla) */
void specialKeyUp(int key, int x, int y)
{

  if (DEBUG)
    printf("Largou a tecla especial %d\n", key);
}


/**************************************
********** CALLBACKS MENU *************
**************************************/

void menu(int op)
{
	switch (op)
	{
	case MENU_EXIT:
		exit(0);
		break;
	case MENU_RESET_CAMERA:
		reset_camera();
		break;
	case MENU_RESET_CAMERAORG:
		reset_camera_org();
		break;
	case MENU_WIREFRAME:
		estado.mode = GLU_LINE;
		break;
	case MENU_SOLID:
		estado.mode = GLU_FILL;
		break;
	case MENU_SHOW_AXIS:
		estado.showAxis = GL_TRUE;
		break;
	case MENU_HIDE_AXIS:
		estado.showAxis = GL_FALSE;
		break;
	}
	glutPostRedisplay();
}


void init_menus()
{
	int mnu = glutCreateMenu(menu);
	glutAddMenuEntry("Wireframe",MENU_WIREFRAME);
	glutAddMenuEntry("Solid",MENU_SOLID);
	glutAddMenuEntry("Mostrar Eixos",MENU_SHOW_AXIS);
	glutAddMenuEntry("Esconder Eixos",MENU_HIDE_AXIS);
	glutAddMenuEntry("Reset Camera",MENU_RESET_CAMERA);
	glutAddMenuEntry("Reset Camera Origem",MENU_RESET_CAMERAORG);
	glutAddMenuEntry("Exit",MENU_EXIT);

	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

/**************************************
************ FUNÇÃO MAIN **************
**************************************/

int main(int argc, char **argv)
{
  init_estado();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition (100, 100);
	glutCreateWindow("Braco robotico #1");
	init();
  init_modelo();
	init_menus();

  imprime_ajuda();

	glutKeyboardFunc(key);
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutMainLoop();

  return 0;
}
