/*
 *  double.c
 *  This is a simple double buffered program.
 *  Pressing the left mouse button rotates the rectangle.
 *  Pressing the middle mouse button stops the rotation.
 */
#if defined(__APPLE__) || defined(MACOSX)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <stdlib.h>
#include <math.h>

#define RAD(x) (M_PI * (x) / 180)
#define GRAUS(x) (180 * (x) / M_PI)

static GLfloat spin = 0.0;
static GLboolean spining = GL_FALSE;

void display(void)
{
   glClear(GL_COLOR_BUFFER_BIT);
   glColor3f(1.0, 1.0, 1.0);
   glBegin(GL_QUADS);
      glVertex2f(25 * cos(RAD(spin)), 25 * sin(RAD(spin)));
      glVertex2f(25 * cos(RAD(spin + 90)), 25 * sin(RAD(spin + 90)));
      glVertex2f(25 * cos(RAD(spin + 180)), 25 * sin(RAD(spin + 180)));
      glVertex2f(25 * cos(RAD(spin + 270)), 25 * sin(RAD(spin + 270)));
   glEnd();
   glutSwapBuffers();
}

void spinDisplay(void)
{
   spin = spin + 2.0;
   if (spin > 360.0)
      spin = spin - 360.0;
   glutPostRedisplay();
}

void anima(int v)
{
   glutTimerFunc(10, anima, 1);
   if(spining){
      spinDisplay();
   }   
}

void init(void)
{
   glClearColor(0.0, 0.0, 0.0, 0.0);
   glShadeModel(GL_FLAT);
}

void reshape(int w, int h)
{
   glViewport(0, 0, (GLsizei)w, (GLsizei)h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-50.0, 50.0, -50.0, 50.0, -1.0, 1.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void mouse(int button, int state, int x, int y)
{
   switch (button)
   {
   case GLUT_LEFT_BUTTON:
      if (state == GLUT_DOWN)
         //glutIdleFunc(spinDisplay);
         spining = GL_TRUE;
      break;
   case GLUT_RIGHT_BUTTON:
      if (state == GLUT_DOWN)
         //glutIdleFunc(NULL);
         spining = GL_FALSE;
      break;
   default:
      break;
   }
}

/* 
 *  Request double buffer display mode.
 *  Register mouse input callback functions
 */
int main(int argc, char **argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
   glutInitWindowSize(250, 250);
   glutInitWindowPosition(100, 100);
   glutCreateWindow("Loop Quad v2");
   init();
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutMouseFunc(mouse);
   glutTimerFunc(10, anima, 1);

   glutMainLoop();
   return 0; /* ANSI C requires main to return int. */
}
