#include <stdlib.h>

#if defined(__APPLE__) || defined(MACOSX)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

/* menu options */
#define MENU_EXIT			1
#define MENU_POLYGON_WIRE	2
#define MENU_POLYGON_SOLID	3
#define MENU_MODE_TRIANGLES	4
#define MENU_MODE_POLYGON	5

/* MODEL DEFINITIONS */


/* application model */

GLfloat colors[][3] = {	
	{1, 0, 0},
	{0, 1, 0},
	{0, 0, 1},
};
GLfloat vertices[][3] = {
	{0.25, 0.25, 0.0},
	{0.75, 0.25, 0.0},
	{0.50, 0.75, 0.0},
};

typedef struct configuracoes_t
{
	GLboolean polygonWire;
	GLenum mode;
} configuracoes_t;

configuracoes_t g_conf;

void init_model()
{
	g_conf.polygonWire = GL_TRUE;
	g_conf.mode = GL_TRIANGLES;
}

/* DRAWING */

void display()
{
	glClear (GL_COLOR_BUFFER_BIT);
	if (g_conf.polygonWire)
		glPolygonMode(GL_FRONT, GL_LINE);
	else
		glPolygonMode(GL_FRONT, GL_FILL);
	glBegin(g_conf.mode);
		glColor3fv (colors[0]);
		glVertex3fv (vertices[0]);
		glColor3fv (colors[1]);
		glVertex3fv (vertices[1]);
		glColor3fv (colors[2]);
		glVertex3fv (vertices[2]);
	glEnd();
	glFlush ();
}

void reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
}

void menu(int op)
{
	switch (op)
	{
	case MENU_EXIT:
		exit(0);
		break;
	case MENU_POLYGON_WIRE:
		g_conf.polygonWire = GL_TRUE;
		break;
	case MENU_POLYGON_SOLID:
		g_conf.polygonWire = GL_FALSE;
		break;
	case MENU_MODE_TRIANGLES:
		g_conf.mode= GL_TRIANGLES;
		break;
	case MENU_MODE_POLYGON:
		g_conf.mode = GL_POLYGON;
		break;
	}
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 27:
		exit(0);
		break;
	case 'w':
	case 'W':
		g_conf.polygonWire = !g_conf.polygonWire;
		break;
	case 't':
	case 'T':
		g_conf.mode = GL_TRIANGLES;
		break;
	case 'p':
	case 'P':
		g_conf.mode = GL_POLYGON;
		break;
	}
		glutPostRedisplay();
}

void init()
{
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
}

void init_menus()
{
	int mnu, mnu1, mnu2;

	mnu1 = glutCreateMenu(menu);
	glutAddMenuEntry("Wireframe", MENU_POLYGON_WIRE);
	glutAddMenuEntry("Solid", MENU_POLYGON_SOLID);

	mnu2 = glutCreateMenu(menu);
	glutAddMenuEntry("GL_TRIANGLES", MENU_MODE_TRIANGLES);
	glutAddMenuEntry("GL_POLYGON", MENU_MODE_POLYGON);

	mnu = glutCreateMenu(menu);
	glutAddSubMenu("glPolygonMode(mode)", mnu1);
	glutAddSubMenu("glBegin(mode)", mnu2);
	glutAddMenuEntry("Exit", MENU_EXIT);
	glutAttachMenu(GLUT_LEFT_BUTTON);
}

int main(int argc, char* argv[])
{
	init_model();

	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize (250, 250);
	glutInitWindowPosition (100, 100);
	glutCreateWindow ("Simple Square GL");
	init ();
	init_menus();
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutMainLoop();

	return 0;
}

