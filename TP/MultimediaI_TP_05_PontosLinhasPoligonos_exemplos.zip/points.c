
/* Copyright (c) Mark J. Kilgard, 1996. */

/* This program is freely distributable without licensing fees 
   and is provided without guarantee or warrantee expressed or 
   implied. This program is -not- in the public domain. */

/* This program is a response to a question posed by Gil Colgate
   <gcolgate@sirius.com> about how lengthy a program is required using
   OpenGL compared to using  Direct3D immediate mode to "draw a
   triangle at screen coordinates 0,0, to 200,200 to 20,200, and I
   want it to be blue at the top vertex, red at the left vertex, and
   green at the right vertex".  I'm not sure how long the Direct3D
   program is; Gil has used Direct3D and his guess is "about 3000
   lines of code". */

/* X compile line: cc -o simple simple.c -lglut -lGLU -lGL -lXmu -lXext -lX11 -lm */

#if defined(__APPLE__) || defined(MACOSX)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <string.h>

void reshape(int w, int h)
{
  /* Because Gil specified "screen coordinates" (presumably with an
     upper-left origin), this short bit of code sets up the coordinate
     system to correspond to actual window coodrinates.  This code
     wouldn't be required if you chose a (more typical in 3D) abstract
     coordinate system. */

  glViewport(0, 0, w, h);       /* Establish viewing area to cover entire window. */
  glMatrixMode(GL_PROJECTION);  /* Start modifying the projection matrix. */
  glLoadIdentity();             /* Reset project matrix. */
  glOrtho(0, w, 0, h, -1, 1);   /* Map abstract coords directly to window coords. */
  glScalef(1, -1, 1);           /* Invert Y axis so increasing Y goes down. */
  glTranslatef(0, -h, 0);       /* Shift origin up to upper-left corner. */
}

void print(char * msg)
{
  glPushMatrix();
  glTranslatef(0, 40, 0);
  glScalef(0.0625, -0.0625, 0.0625);
  for (int i = 0; i < strlen(msg); i++)
	glutStrokeCharacter(GLUT_STROKE_ROMAN, msg[i]);
  glPopMatrix();
}

void draw(GLfloat sz, char* msg)
{
	glPushMatrix();
	glPointSize(sz);
  glBegin(GL_POINTS);
    glVertex2i(10, 20);
	glVertex2i(10, 10);
    glVertex2i(20, 15);
	glVertex2i(20, 5);
	glVertex2i(30, 15);
	glVertex2i(30, 5);
	glVertex2i(40, 20);
	glVertex2i(40, 10);
  glEnd();
  glPopMatrix();

  print(msg);
}


void display(void)
{
  glClear(GL_COLOR_BUFFER_BIT);

  glScalef(2, 2, 2);

  glTranslatef(0, 0, 0);
  draw(1, "1.0");

  glTranslatef(100, 0, 0);
  draw(2, "2.0");

    glTranslatef(100, 0, 0);
  draw(3, "3.0");

    glTranslatef(100, 0, 0);
  draw(4, "4.0");

    glTranslatef(-300, 50, 0);
  draw(5, "5.0");

    glTranslatef(100, 0, 0);
  draw(6, "6.0");

    glTranslatef(100, 0, 0);
  draw(7, "7.0");

      glTranslatef(100, 0, 0);
  draw(8, "8.0");
  glFlush();  /* Single buffered, so needs a flush. */
}

int main(int argc, char **argv)
{
  glutInit(&argc, argv);
  glutInitWindowSize(800, 400);
  glutCreateWindow("Points");
  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutMainLoop();
  return 0;             /* ANSI C requires main to return int. */
}
