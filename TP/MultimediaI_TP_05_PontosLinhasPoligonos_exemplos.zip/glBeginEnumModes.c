
/* Copyright (c) Mark J. Kilgard, 1996. */

/* This program is freely distributable without licensing fees 
   and is provided without guarantee or warrantee expressed or 
   implied. This program is -not- in the public domain. */

/* This program is a response to a question posed by Gil Colgate
   <gcolgate@sirius.com> about how lengthy a program is required using
   OpenGL compared to using  Direct3D immediate mode to "draw a
   triangle at screen coordinates 0,0, to 200,200 to 20,200, and I
   want it to be blue at the top vertex, red at the left vertex, and
   green at the right vertex".  I'm not sure how long the Direct3D
   program is; Gil has used Direct3D and his guess is "about 3000
   lines of code". */

/* X compile line: cc -o simple simple.c -lglut -lGLU -lGL -lXmu -lXext -lX11 -lm */

#if defined(__APPLE__) || defined(MACOSX)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <string.h>

void reshape(int w, int h)
{
  /* Because Gil specified "screen coordinates" (presumably with an
     upper-left origin), this short bit of code sets up the coordinate
     system to correspond to actual window coodrinates.  This code
     wouldn't be required if you chose a (more typical in 3D) abstract
     coordinate system. */

  glViewport(0, 0, w, h);       /* Establish viewing area to cover entire window. */
  glMatrixMode(GL_PROJECTION);  /* Start modifying the projection matrix. */
  glLoadIdentity();             /* Reset project matrix. */
  glOrtho(0, w, 0, h, -1, 1);   /* Map abstract coords directly to window coords. */
  glScalef(1, -1, 1);           /* Invert Y axis so increasing Y goes down. */
  glTranslatef(0, -h, 0);       /* Shift origin up to upper-left corner. */
}

void print(char * msg)
{
  glPushMatrix();
  glTranslatef(0, 40, 0);
  glScalef(0.0625, -0.0625, 0.0625);
  for (int i = 0; i < strlen(msg); i++)
	glutStrokeCharacter(GLUT_STROKE_ROMAN, msg[i]);
  glPopMatrix();
}

void draw(GLenum mode, char* msg)
{
	glPushMatrix();
  glBegin(mode);
    glVertex2i(10, 20);
	glVertex2i(10, 10);
    glVertex2i(20, 15);
	glVertex2i(20, 5);
	glVertex2i(30, 15);
	glVertex2i(30, 5);
	glVertex2i(40, 20);
	glVertex2i(40, 10);
	// o proximo vertice é ignorado no caso de QUAD e QUAD_STRIP
	// e TEM que ser omitido no caso de GL_POLIGON para não gerar poligono convexo
	if (mode != GL_POLYGON)
		glVertex2i(50, 30);
  glEnd();
  glPopMatrix();

	print(msg);
}

void drawQUADS()
{
	// os mesmos vértices mas a ordem é importante
	// devem ser indicados em "loop" CW/CCW
	glPushMatrix();
  glBegin(GL_QUADS);
    glVertex2i(10, 20);
	glVertex2i(10, 10);
	glVertex2i(20, 5);
    glVertex2i(20, 15);

	glVertex2i(30, 5);
	glVertex2i(30, 15);
	glVertex2i(40, 20);
	glVertex2i(40, 10);
  glEnd();
  glPopMatrix();

	print("GL_QUADS");
}

void drawTRIANGLE_FAN()
{
	glPushMatrix();
  glBegin(GL_TRIANGLE_FAN);
    glVertex2i(25, 20);
	glVertex2i(10, 10);
    glVertex2i(10, 25);
	glVertex2i(25, 30);
	glVertex2i(35, 15);
  glEnd();
  glPopMatrix();

  print("GL_TRIANGLE_FAN");
}

void drawPOLYGON()
{
	glPushMatrix();
  glBegin(GL_POLYGON);
	glVertex2i(10, 10);
    glVertex2i(10, 20);
	glVertex2i(20, 25);
	glVertex2i(30, 20);
	glVertex2i(30, 10);
	glVertex2i(20, 5);
  glEnd();
  glPopMatrix();

  print ("GL_POLYGON");
}

void display(void)
{
  glClear(GL_COLOR_BUFFER_BIT);

  glScalef(2, 2, 2);

  glTranslatef(0, 0, 0);
  draw(GL_POINTS, "GL_POINTS");

  glTranslatef(100, 0, 0);
  draw(GL_LINES, "GL_LINES");

    glTranslatef(100, 0, 0);
  draw(GL_LINE_STRIP, "GL_LINE_STRIP");

    glTranslatef(100, 0, 0);
  draw(GL_LINE_LOOP, "GL_LINE_LOOP");

    glTranslatef(-300, 50, 0);
  draw(GL_TRIANGLES, "GL_TRIANGLES");

    glTranslatef(100, 0, 0);
  draw(GL_TRIANGLE_STRIP, "GL_TRIANGLE_STRIP");

    glTranslatef(100, 0, 0);
  drawTRIANGLE_FAN();

    glTranslatef(-200, 50, 0);
  drawQUADS();

    glTranslatef(100, 0, 0);
  draw(GL_QUAD_STRIP, "GL_QUAD_STRIP");

  glTranslatef(100, 0, 0);
  drawPOLYGON();

	glTranslatef(100, 0, 0);
	glRecti(10, 10, 30, 30);
	print("glRect");
  
  glFlush();  /* Single buffered, so needs a flush. */
}

int main(int argc, char **argv)
{
  glutInit(&argc, argv);
  glutInitWindowSize(800, 400);
  glutCreateWindow("glBegin enum modes");
  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutMainLoop();
  return 0;             /* ANSI C requires main to return int. */
}
