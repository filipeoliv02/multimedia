#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "glm.h"

#if defined(__APPLE__) || defined(MACOSX)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#define DEBUG 0
#define QTD_TEXT 3

typedef struct {
  GLboolean   doubleBuffer;
  GLint       delay;
  GLboolean	usaLuz;
}Estado;

typedef struct {
  GLfloat     ang_h;
  GLfloat     ang_v;
  GLfloat     dist;
}Camara;

typedef struct {
	GLuint textura[QTD_TEXT];
	GLboolean esfera;
	GLboolean usaTextura;
}Modelo;

Estado estado;
Camara camara;
Modelo modelo;

void gerarTexturas(void)
{
   unsigned char *image = NULL;
   int w, h;

   glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

   glGenTextures(QTD_TEXT, modelo.textura);

   image = glmReadPPM("data/textura.ppm",&w, &h);
   glBindTexture(GL_TEXTURE_2D, modelo.textura[0]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
   gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, w, h, GL_RGB, GL_UNSIGNED_BYTE, image);

   image = glmReadPPM("data/textura-2.ppm",&w, &h);
   glBindTexture(GL_TEXTURE_2D, modelo.textura[1]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
   gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, w, h, GL_RGB, GL_UNSIGNED_BYTE, image);

   image = glmReadPPM("data/textura-3.ppm",&w, &h);
   glBindTexture(GL_TEXTURE_2D, modelo.textura[2]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
   gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, w, h, GL_RGB, GL_UNSIGNED_BYTE, image);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
}

void init(void)
{
  glClearColor(0.0, 0.0, 0.0, 0.0);

  glEnable(GL_DEPTH_TEST);
  glEnable(GL_POINT_SMOOTH);
  glEnable(GL_LINE_SMOOTH);
  glEnable(GL_POLYGON_SMOOTH);
  glEnable(GL_CULL_FACE);
  camara.ang_h = 45.0;
  camara.ang_v = 45.0;
  camara.dist = 3.0;
  
  gerarTexturas();

}

void reshape(int width, int height)
{
  GLint size;

  if (width < height)
    size = width;
  else
    size = height;

  glViewport(0, 0, (GLint) size, (GLint) size);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  gluPerspective(45.0, 1.0, 0.1, 10.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void desenhaPoligono(GLfloat a[], GLfloat b[], GLfloat c[], GLfloat  d[], GLfloat cor[])
{
  glBegin(GL_POLYGON);
    glColor3fv(cor);
	glTexCoord2f(0.0, 0.0);
    glVertex3fv(a);
	glTexCoord2f(1.0, 0.0);
    glVertex3fv(b);
	glTexCoord2f(1.0, 1.0);
    glVertex3fv(c);
	glTexCoord2f(0.0, 1.0);
    glVertex3fv(d);
  glEnd();
}

void desenhaCubo(void)
{
  GLfloat vertices[][3] = {
				{-0.5,-0.5,-0.5}, 
                {0.5,-0.5,-0.5}, 
                {0.5,0.5,-0.5}, 
                {-0.5,0.5,-0.5}, 
                {-0.5,-0.5,0.5},  
                {0.5,-0.5,0.5}, 
                {0.5,0.5,0.5}, 
                {-0.5,0.5,0.5}
  };

  GLfloat cores[][3] = {
						            {0.0,1.0,1.0},
                        {1.0,0.0,0.0},
                        {1.0,1.0,0.0}, 
                        {0.0,1.0,0.0}, 
                        {1.0,0.0,1.0}, 
                        {0.0,0.0,1.0}, 
                        {1.0,1.0,1.0}
  };

  glBindTexture(GL_TEXTURE_2D, modelo.textura[0]);
  desenhaPoligono(vertices[1],vertices[0],vertices[3],vertices[2],cores[0]);
  desenhaPoligono(vertices[2],vertices[3],vertices[7],vertices[6],cores[5]);
  glBindTexture(GL_TEXTURE_2D, modelo.textura[1]);
  desenhaPoligono(vertices[3],vertices[0],vertices[4],vertices[7],cores[2]);
  desenhaPoligono(vertices[6],vertices[5],vertices[1],vertices[2],cores[3]);
  glBindTexture(GL_TEXTURE_2D, modelo.textura[2]);
  desenhaPoligono(vertices[4],vertices[5],vertices[6],vertices[7],cores[4]);
  desenhaPoligono(vertices[5],vertices[4],vertices[0],vertices[1],cores[6]);
}

void draw(void)
{
  
  if (modelo.usaTextura)
		glEnable(GL_TEXTURE_2D);
	else
		glDisable(GL_TEXTURE_2D);
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  
  glPushMatrix();
    glTranslatef(0.0, 0.0, -camara.dist);
    glRotatef(camara.ang_v, 1.0, 0.0, 0.0);
    glRotatef(camara.ang_h, 0.0, 1.0, 0.0);

    if (estado.usaLuz)
    {
      glEnable(GL_LIGHTING);
      glEnable(GL_LIGHT0);
      glEnable(GL_COLOR_MATERIAL);

      float pos[] = {2, 2, 2, 0};
      glLightfv(GL_LIGHT0, GL_POSITION, pos);
    }
    else
    {
      glDisable(GL_LIGHTING);
    }
    if (!modelo.esfera)
    {
      desenhaCubo();
    }
    else
    {
      glBindTexture(GL_TEXTURE_2D, modelo.textura[0]);

      float amb[] = {1, 1, 1, 1};
      glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, amb);
      GLUquadricObj* l_poQuadric = gluNewQuadric();
      gluQuadricDrawStyle(l_poQuadric, GLU_FILL);
      gluQuadricNormals(l_poQuadric, GLU_SMOOTH);

      if (modelo.usaTextura)
        gluQuadricTexture(l_poQuadric, GL_TRUE); 
    
      gluSphere(l_poQuadric, 1, 30, 30);
      gluDeleteQuadric(l_poQuadric);
    }    

  glPopMatrix();

  glFlush();
  if (estado.doubleBuffer)
    glutSwapBuffers();
}

void imprime_ajuda(void)
{
  printf("\n\nExemplo Texturas:\n");
  printf("h,H             - Ajuda \n");
  printf("Setas           - Rotação da câmara\n");
  printf("PageUp,PageDown - Distância da camara ao cubo\n");
  printf("l,L             - Toggle iluminação \n");
  printf("t,T             - Toggle texturas \n");
  printf("ESC - Sair\n");
}

void key(unsigned char key, int x, int y)
{
  switch (key) {
    case 27:
      exit(1);
    case ' ':
      modelo.esfera = !modelo.esfera;
      glutPostRedisplay();
      break;
    case 'l':
    case 'L':
      estado.usaLuz = !estado.usaLuz;
      printf("Iluminação: %s\n", (estado.usaLuz ? "ON" : "off"));
      glutPostRedisplay();
      break;
    case 't':
    case 'T':
      modelo.usaTextura = !modelo.usaTextura;
      printf("Textura: %s\n", (modelo.usaTextura ? "ON" : "off"));
      glutPostRedisplay();
      break;
    case 'h' :
    case 'H' :
      imprime_ajuda();
      break;
  }

  if(DEBUG)
    printf("Carregou na tecla %c\n",key);

}

void specialKey(int key, int x, int y)
{
  // ... accoes sobre outras teclas especiais ... 
  //    GLUT_KEY_F1 ... GLUT_KEY_F12
  //    GLUT_KEY_UP
  //    GLUT_KEY_DOWN
  //    GLUT_KEY_LEFT
  //    GLUT_KEY_RIGHT
  //    GLUT_KEY_PAGE_UP
  //    GLUT_KEY_PAGE_DOWN
  //    GLUT_KEY_HOME
  //    GLUT_KEY_END
  //    GLUT_KEY_INSERT 

  switch (key) {
	case GLUT_KEY_LEFT:
		camara.ang_h -= 5;
		break;
	case GLUT_KEY_RIGHT:
		camara.ang_h += 5;
		break;
	case GLUT_KEY_DOWN:
		camara.ang_v -= 5;
		break;
	case GLUT_KEY_UP:
		camara.ang_v += 5;
		break;
	case GLUT_KEY_PAGE_UP:
		camara.dist /= 1.1;
		break;
	case GLUT_KEY_PAGE_DOWN:
		camara.dist *= 1.1;
		break;
  }
  if(DEBUG)
    printf("angH = %f graus, angV = %f graus, Dist = %f\n", camara.ang_h, camara.ang_v, camara.dist);
  
  
  glutPostRedisplay();

  if(DEBUG)
    printf("Carregou na tecla especial %d\n",key);
}


int main(int argc, char **argv)
{
  estado.doubleBuffer=GL_TRUE;

  glutInit(&argc, argv);
  glutInitWindowPosition(0, 0);
  glutInitWindowSize(300, 300);
  glutInitDisplayMode((estado.doubleBuffer) ? GLUT_DOUBLE : GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
  if (glutCreateWindow("Exemplo Texturas") == GL_FALSE)
    exit(1);

  init();

  imprime_ajuda();
  
  glutReshapeFunc(reshape);
  glutDisplayFunc(draw);

  glutKeyboardFunc(key);
  glutSpecialFunc(specialKey);

  glutMainLoop();

  return 0;
}
